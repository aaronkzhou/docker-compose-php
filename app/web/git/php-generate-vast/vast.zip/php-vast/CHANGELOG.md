## 0.3 (2016-03-24)
  * Add support of Wrapper's VASTAdTagURI element
  * Private methods and properties now without underscores